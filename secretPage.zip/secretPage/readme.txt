=== Secret Page ===
Tags: secret, protect, access, users, list, save, export, import
Requires: 3.5
License: The MIT License (MIT)
License URI: http://opensource.org/licenses/MIT

This plugin permit to centralize an access on secrets pages by codes.

== Description ==

This plugin permit to centralize an access on secrets pages by codes.

This plugin :
- Automatically redirect on the page which is associated to the code.
- Protect data on the secret page, if code are not sended
- Save the user email
- Display all email address on the admin part


For developers : 
- You can change the name of markers and all wording on the define.php page.

